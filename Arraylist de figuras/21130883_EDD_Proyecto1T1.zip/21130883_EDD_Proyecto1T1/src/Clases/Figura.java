
package Clases;

import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;

public class Figura {
    private int num;
    private String nombre;
   
    
    public Figura(){
        this.num=0;
        this.nombre="";
       
    }
   
    public Figura(int num, String nombre) {
        this.num = num;
        this.nombre = nombre;
        
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void generarFiguraAleatoria(JTable tabla,JLabel lbl){
        
        Random azar = new Random();
        String [] nombres ={"Triangulo","Cuadrado","Rectangulo","Ovalo"};
        
        
        Figura oFig = new Figura(azar.nextInt(1000)+1,nombres[azar.nextInt(nombres.length)]);
        
        tabla.setValueAt(oFig.getNum(), 0, 0);
        tabla.setValueAt(oFig.getNombre(), 0, 1);
        switch(oFig.getNombre()){
            case "Triangulo":
                lbl.setIcon(new ImageIcon(getClass().getResource("/Images/triangulo.png")));
           
                break;
            
            case "Cuadrado":
                lbl.setIcon(new ImageIcon(getClass().getResource("/Images/cuadrado.png")));
                
                break;
                
            case "Rectangulo":
                lbl.setIcon(new ImageIcon(getClass().getResource("/Images/rectangulo.png")));
                
                break;
                
            case "Ovalo":
                lbl.setIcon(new ImageIcon(getClass().getResource("/Images/ovalo.png")));
                
                break;
            
        }
        
    }
}
