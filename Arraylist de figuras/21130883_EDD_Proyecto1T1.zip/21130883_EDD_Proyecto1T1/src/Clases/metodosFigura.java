
package Clases;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class metodosFigura {
    public ArrayList <Figura> arrLFig;
    
    public metodosFigura(){
        this.arrLFig=new ArrayList();
    }
    
    
    public void guardarFig(Figura oFig){
        arrLFig.add(oFig);
    }
    
    public void eliminarFig(int index){
        try{
            arrLFig.remove(index);
        }catch(IndexOutOfBoundsException e){
            JOptionPane.showMessageDialog(null, e.toString());
        }
        
    }
    
    public void mostrarFigs(JTable tabla){
        DefaultTableModel modelo = (DefaultTableModel)tabla.getModel();
        
        modelo.setRowCount(arrLFig.size());
        
        for(int i=0; i<arrLFig.size();i++){
            modelo.setValueAt(arrLFig.get(i).getNum(), i, 0);
            modelo.setValueAt(arrLFig.get(i).getNombre(), i, 1);
        }
        
        
    }
    
    public void modificarFig(int index, Figura oFig){
        arrLFig.set(index, oFig);
        
    }
    
    public int buscarFig(int numFig,JTable tabla){
        int indice=-1;
        for(int i=0; i<arrLFig.size();i++){
            if(numFig == arrLFig.get(i).getNum()){
                indice = i;
                tabla.setValueAt(arrLFig.get(i).getNum(), 0, 0);
                tabla.setValueAt(arrLFig.get(i).getNombre(), 0, 1);
                
                break;
            }
                
        }
        
        return indice;
        
    }
    
     public int buscarFig(int numFig){
        int indice=-1;
        for(int i=0; i<arrLFig.size();i++){
            if(numFig == arrLFig.get(i).getNum()){
                indice = i;
                break;
            }
                
        }
        
        return indice;
        
    }
     
     public void buscarMostrarNombre(String nombre,JList lista){
         DefaultListModel modelo = new DefaultListModel();
         String cad = "";
         for(int i=0;i<arrLFig.size();i++){
             if(nombre.equals(arrLFig.get(i).getNombre())){
                 cad = "Numero: "+arrLFig.get(i).getNum()+" Nombre: "+arrLFig.get(i).getNombre();
                 modelo.addElement(cad);
             }
             lista.setModel(modelo);
         }
     }
}
